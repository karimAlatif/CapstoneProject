# CapstoneProject

# Video URL (Pc):  https://bit.ly/2H6ipKk
# Video Url (Mobile):  https://bit.ly/2TLeFiK
  
# #Fundamentals


# 1. Scale achievement (100 points) 
	-Normal size 
# 2. Animation achievement (100 points) 
	-Door Animation
	-Text Animation

# 3. Lighting achievement (100 points) 
	-All Light are Baked to enhace the proformence
# 4. Locomotion achievement (100 points) 
	-Player Can move on any walkable area
# 5. Video Player achievement (100 points) x2  
	-Video Player that Show Game Rules


# Total : 600 points



# #Completeness

# 1. Gamification achievement (250 points)
	-there is reward system that Calculate user points when he answers correclty
# 2. Diegetic UI achievement (250 points) 
	-there is alot of Ui that helps to guid the user in the tour
# 3. Alternative Storyline achievement (250 points)  
	-user can choose between 3 modes before starting the tour
# 4. 3D Modeling achievement (250 points) 
	- i designed simple paper and used it as projector screen to display rules and infos
  
# Total: 1000 Points



# #Challenges

# 1. User Testing achievement (250 points) x2
	-in testing Stage, I choose three users to match my target user for my project.
	 I decided to ask them the same questions in to get pure info so I can enhance my Project

# My Questions were:
Q1: How you feel about the size of the scene? if it is which item you feel it’s big?

Q2: What kind of mood are you feel in this scene?

Q3: Is the scene uncomfortable?

Q4: Did you like the questions?

Q5:What is your idea to improve it ?

Q6: Did you get a good VR Experience from this project?

I used an htc desire 10 pro with paired with Google Cardboard for testing

# User test 1
The first user test told me to enhance the Quailty of Questions that are Exists ...he felt it's not achallenged
  Improvement
	I had adjusted the quality of questions a little bit and added one hidden info in last room so made it a bit achallenged

# User test 2
The Second user test told me to add more than mode of questions to choose from..he felt Boared.

Improvement
	I had adjusted that , i have added 3 modes to choose from with reward system to calculate user points.

# User test 3
User 3 liked the experience as VR tour and  feel good about all info's and questions that are exists in the game
and felt it is a usful tour

# Total: 500 Points
